# Builds thali-coach.apk from the bundled web app. No Gradle, no internet.
# Requires: Android SDK build-tools + platform, and a JDK (Android Studio's jbr).
$ErrorActionPreference = 'Stop'

$proj = "C:\Users\DELL\thali-coach-android"
$web  = "C:\Users\DELL\thali-coach"
$sdk  = "C:\Users\DELL\AppData\Local\Android\Sdk"
$bt   = "$sdk\build-tools\35.0.0"
$jar  = "$sdk\platforms\android-35\android.jar"
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

Set-Location $proj
Remove-Item build -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path build, build\dex, build\classes | Out-Null

Write-Host "1/7  copying web assets"
$www = Join-Path $proj "assets\www"
Remove-Item $www -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $www | Out-Null
Get-ChildItem $web -File | Where-Object { $_.Extension -in '.html', '.css', '.js', '.json', '.svg', '.png' } |
  Where-Object { $_.Name -ne 'serve.js' } |
  Copy-Item -Destination $www -Force

Write-Host "2/7  compiling resources"
& "$bt\aapt2.exe" compile --dir res -o build\res.zip
if ($LASTEXITCODE -ne 0) { throw "aapt2 compile failed" }

Write-Host "3/7  linking resources"
& "$bt\aapt2.exe" link -o build\base.apk -I $jar --manifest AndroidManifest.xml build\res.zip `
  --java build\gen --min-sdk-version 23 --target-sdk-version 35
if ($LASTEXITCODE -ne 0) { throw "aapt2 link failed" }

Write-Host "4/7  compiling java"
$sources = @()
$sources += (Get-ChildItem src -Recurse -Filter *.java | ForEach-Object { $_.FullName })
$sources += (Get-ChildItem build\gen -Recurse -Filter *.java | ForEach-Object { $_.FullName })
& "$env:JAVA_HOME\bin\javac.exe" -source 11 -target 11 -classpath $jar -d build\classes $sources
if ($LASTEXITCODE -ne 0) { throw "javac failed" }

Write-Host "5/7  dexing"
$classes = Get-ChildItem build\classes -Recurse -Filter *.class | ForEach-Object { $_.FullName }
& "$bt\d8.bat" --release --lib $jar --min-api 23 --output build\dex $classes
if ($LASTEXITCODE -ne 0) { throw "d8 failed" }

Write-Host "6/7  packaging + aligning"
Copy-Item build\base.apk build\app-unsigned.apk -Force
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open("$proj\build\app-unsigned.apk", [System.IO.Compression.ZipArchiveMode]::Update)
$old = $zip.GetEntry("classes.dex"); if ($old) { $old.Delete() }
$entry = $zip.CreateEntry("classes.dex", [System.IO.Compression.CompressionLevel]::NoCompression)
$stream = $entry.Open()
$bytes = [System.IO.File]::ReadAllBytes("$proj\build\dex\classes.dex")
$stream.Write($bytes, 0, $bytes.Length)
$stream.Dispose()

# Add web assets ourselves. aapt2 on Windows stores them with backslashes,
# which Android's AssetManager cannot open; ZIP entry names must use "/".
$assetRoot = (Join-Path $proj "assets").TrimEnd('\')
Get-ChildItem $assetRoot -Recurse -File | ForEach-Object {
  $rel = $_.FullName.Substring($assetRoot.Length + 1).Replace('\', '/')
  $name = "assets/" + $rel
  $oldAsset = $zip.GetEntry($name); if ($oldAsset) { $oldAsset.Delete() }
  $assetEntry = $zip.CreateEntry($name, [System.IO.Compression.CompressionLevel]::Optimal)
  $assetStream = $assetEntry.Open()
  $assetBytes = [System.IO.File]::ReadAllBytes($_.FullName)
  $assetStream.Write($assetBytes, 0, $assetBytes.Length)
  $assetStream.Dispose()
}
$zip.Dispose()

& "$bt\zipalign.exe" -p -f 4 build\app-unsigned.apk build\app-aligned.apk
if ($LASTEXITCODE -ne 0) { throw "zipalign failed" }

Write-Host "7/7  signing + verifying"
& "$bt\apksigner.bat" sign --ks "$proj\thali-release.keystore" --ks-key-alias thali `
  --ks-pass pass:thali12345 --key-pass pass:thali12345 `
  --out "$proj\thali-coach.apk" "$proj\build\app-aligned.apk"
if ($LASTEXITCODE -ne 0) { throw "apksigner failed" }

& "$bt\apksigner.bat" verify "$proj\thali-coach.apk"
if ($LASTEXITCODE -ne 0) { throw "signature verification failed" }

Copy-Item "$proj\thali-coach.apk" "$web\download\thali-coach.apk" -Force
$apk = Get-Item "$web\download\thali-coach.apk"
Write-Host ("BUILT  {0}  {1:N0} bytes" -f $apk.FullName, $apk.Length)

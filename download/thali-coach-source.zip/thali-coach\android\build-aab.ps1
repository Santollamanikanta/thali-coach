# Builds thali-coach.aab (Android App Bundle) for Google Play.
# No Gradle: aapt2 proto-format -> javac -> d8 -> module zip -> bundletool -> jarsigner.
# Requires bundletool.jar in this folder (download from github.com/google/bundletool/releases).
$ErrorActionPreference = 'Stop'

$proj = "C:\Users\DELL\thali-coach-android"
$web  = "C:\Users\DELL\thali-coach"
$sdk  = "C:\Users\DELL\AppData\Local\Android\Sdk"
$bt   = "$sdk\build-tools\35.0.0"
$jar  = "$sdk\platforms\android-35\android.jar"
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

Set-Location $proj
$out = Join-Path $proj "build-aab"
Remove-Item $out -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path `
  "$out\gen", "$out\classes", "$out\dex", "$out\module\manifest", "$out\module\dex", "$out\module\res", "$out\module\assets\www" | Out-Null

Write-Host "1/7  copying web assets"
Get-ChildItem $web -File | Where-Object { $_.Extension -in '.html', '.css', '.js', '.json', '.svg', '.png' } |
  Where-Object { $_.Name -ne 'serve.js' } |
  Copy-Item -Destination "$out\module\assets\www" -Force

Write-Host "2/7  compiling resources"
& "$bt\aapt2.exe" compile --dir res -o "$out\res.zip"
if ($LASTEXITCODE -ne 0) { throw "aapt2 compile failed" }

Write-Host "3/7  linking resources (proto)"
& "$bt\aapt2.exe" link -o "$out\base-proto.apk" -I $jar --manifest AndroidManifest.xml `
  --proto-format "$out\res.zip" --java "$out\gen" --min-sdk-version 23 --target-sdk-version 35
if ($LASTEXITCODE -ne 0) { throw "aapt2 proto link failed" }

Write-Host "4/7  compiling java"
$sources = @()
$sources += (Get-ChildItem src -Recurse -Filter *.java | ForEach-Object { $_.FullName })
$sources += (Get-ChildItem "$out\gen" -Recurse -Filter *.java | ForEach-Object { $_.FullName })
& "$env:JAVA_HOME\bin\javac.exe" -source 11 -target 11 -classpath $jar -d "$out\classes" $sources
if ($LASTEXITCODE -ne 0) { throw "javac failed" }

Write-Host "5/7  dexing"
$classes = Get-ChildItem "$out\classes" -Recurse -Filter *.class | ForEach-Object { $_.FullName }
& "$bt\d8.bat" --release --lib $jar --min-api 23 --output "$out\dex" $classes
if ($LASTEXITCODE -ne 0) { throw "d8 failed" }

Write-Host "6/7  assembling module + bundle"
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

# Unpack aapt2's proto apk (manifest + resources.pb + res/) into the module layout.
$proto = [System.IO.Compression.ZipFile]::OpenRead("$out\base-proto.apk")
foreach ($e in $proto.Entries) {
  $name = $e.FullName.Replace('\', '/')
  $target = $null
  if ($name -eq 'AndroidManifest.xml') { $target = "$out\module\manifest\AndroidManifest.xml" }
  elseif ($name -eq 'resources.pb')    { $target = "$out\module\resources.pb" }
  elseif ($name -like 'res/*')          { $target = Join-Path "$out\module" $name.Replace('/', '\') }
  if ($target) {
    New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
  }
}
$proto.Dispose()

Copy-Item "$out\dex\classes.dex" "$out\module\dex\classes.dex" -Force

# Module zip: entry names must use forward slashes.
$moduleZip = "$out\base.zip"
if (Test-Path $moduleZip) { Remove-Item $moduleZip -Force }
$zip = [System.IO.Compression.ZipFile]::Open($moduleZip, [System.IO.Compression.ZipArchiveMode]::Create)
$moduleRoot = (Join-Path $out "module").TrimEnd('\')
Get-ChildItem $moduleRoot -Recurse -File | ForEach-Object {
  $rel = $_.FullName.Substring($moduleRoot.Length + 1).Replace('\', '/')
  $entry = $zip.CreateEntry($rel, [System.IO.Compression.CompressionLevel]::Optimal)
  $s = $entry.Open()
  $b = [System.IO.File]::ReadAllBytes($_.FullName)
  $s.Write($b, 0, $b.Length)
  $s.Dispose()
}
$zip.Dispose()

Remove-Item "$proj\thali-coach-unsigned.aab" -Force -ErrorAction SilentlyContinue
& "$env:JAVA_HOME\bin\java.exe" -jar "$proj\bundletool.jar" build-bundle `
  --modules="$moduleZip" --output="$proj\thali-coach-unsigned.aab"
if ($LASTEXITCODE -ne 0) { throw "bundletool build-bundle failed" }

Write-Host "7/7  signing bundle"
& "$env:JAVA_HOME\bin\jarsigner.exe" -keystore "$proj\thali-release.keystore" `
  -storepass thali12345 -keypass thali12345 -sigalg SHA256withRSA -digestalg SHA-256 `
  "$proj\thali-coach-unsigned.aab" thali
if ($LASTEXITCODE -ne 0) { throw "jarsigner failed" }

& "$env:JAVA_HOME\bin\jarsigner.exe" -verify "$proj\thali-coach-unsigned.aab"
if ($LASTEXITCODE -ne 0) { throw "AAB signature verification failed" }

Copy-Item "$proj\thali-coach-unsigned.aab" "$proj\thali-coach.aab" -Force
Copy-Item "$proj\thali-coach.aab" "$web\download\thali-coach.aab" -Force
$bundle = Get-Item "$web\download\thali-coach.aab"
Write-Host ("BUILT  {0}  {1:N0} bytes" -f $bundle.FullName, $bundle.Length)

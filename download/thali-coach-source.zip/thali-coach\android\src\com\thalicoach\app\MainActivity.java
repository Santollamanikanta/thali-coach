package com.thalicoach.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    /* Assets are served from this fake https origin so localStorage gets a
       real, stable origin (file:// origins are opaque in modern WebView). */
    private static final String HOST = "app.thali.local";
    private static final String BASE = "https://" + HOST;
    private static final int FILE_CHOOSER = 1001;

    private static final Map<String, String> MIME = new HashMap<String, String>();
    static {
        MIME.put("html", "text/html");
        MIME.put("css", "text/css");
        MIME.put("js", "application/javascript");
        MIME.put("json", "application/json");
        MIME.put("webmanifest", "application/manifest+json");
        MIME.put("svg", "image/svg+xml");
        MIME.put("png", "image/png");
        MIME.put("ico", "image/x-icon");
    }

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraUri;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#EEFAF2"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        /* The plate photo arrives as a content:// URI from the camera or the
           photo picker, so content access has to stay on. */
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                String url = req.getUrl().toString();
                if (!url.startsWith(BASE)) return null;

                String path = url.substring(BASE.length());
                int cut = path.indexOf('?');
                if (cut >= 0) path = path.substring(0, cut);
                cut = path.indexOf('#');
                if (cut >= 0) path = path.substring(0, cut);
                if (path.isEmpty() || path.equals("/")) path = "/index.html";

                /* No service worker inside the shell: the app is already local,
                   and a stale SW cache would hide future asset updates. */
                if (path.equals("/sw.js")) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                            new HashMap<String, String>(),
                            new ByteArrayInputStream("no service worker in the app shell".getBytes()));
                }

                try {
                    InputStream in = getAssets().open("www" + path);
                    int dot = path.lastIndexOf('.');
                    String ext = dot >= 0 ? path.substring(dot + 1).toLowerCase() : "";
                    String mime = MIME.containsKey(ext) ? MIME.get(ext) : "application/octet-stream";
                    Map<String, String> headers = new HashMap<String, String>();
                    headers.put("Cache-Control", "no-store");
                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                            new HashMap<String, String>(),
                            new ByteArrayInputStream("Not found".getBytes()));
                }
            }

            /* Source code, licence and download links belong in the phone's
               browser, not inside the offline shell. */
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return openExternally(req.getUrl());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternally(Uri.parse(url));
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                cameraUri = null;

                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");

                Intent chooser = Intent.createChooser(pick, "Photo of your plate");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                /* Put the camera first, but always keep the photo picker as a
                   fallback for phones without a camera app. */
                try {
                    File dir = new File(getCacheDir(), "photos");
                    if (!dir.exists()) dir.mkdirs();
                    File out = new File(dir, "plate_" + System.currentTimeMillis() + ".jpg");
                    cameraUri = PhotoProvider.uriFor(MainActivity.this, out);
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{ camera });
                } catch (Exception e) {
                    cameraUri = null;
                }

                try {
                    startActivityForResult(chooser, FILE_CHOOSER);
                } catch (Exception e) {
                    filePathCallback = null;
                    cameraUri = null;
                    return false;
                }
                return true;
            }
        });

        setContentView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (saved == null) web.loadUrl(BASE + "/index.html");
        else web.restoreState(saved);
    }

    private boolean openExternally(Uri uri) {
        if (uri == null) return false;
        if (uri.toString().startsWith(BASE)) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            /* No browser installed: keep the app where it is. */
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    result = new Uri[]{ data.getData() };
                } else if (cameraUri != null) {
                    result = new Uri[]{ cameraUri };
                }
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            cameraUri = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }
}
